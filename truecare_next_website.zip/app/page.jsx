import { Heart, ShieldCheck, Home, ShoppingBasket, Coffee, Pill, Phone, Mail, MapPin, Users, Sparkles } from 'lucide-react';

const services = [
  { icon: Users, title: 'Companionship', text: 'Friendly visits, conversation, reassurance and meaningful time together.' },
  { icon: Home, title: 'Household Help', text: 'Light cleaning, laundry, tidying and keeping the home comfortable.' },
  { icon: ShoppingBasket, title: 'Shopping & Errands', text: 'Support with shopping, prescriptions, appointments and daily tasks.' },
  { icon: Coffee, title: 'Meals & Drinks', text: 'Preparing simple meals, hot drinks and gentle encouragement to eat well.' },
  { icon: Pill, title: 'Medication Reminders', text: 'Kind prompts to help people stay on track with their routine.' },
  { icon: ShieldCheck, title: 'Welfare Checks', text: 'Regular visits for reassurance, safety checks and peace of mind.' }
];

export default function Page() {
  return (
    <main>
      <header className="header">
        <a className="brand" href="#home">
          <div className="mark"><Heart size={26} /></div>
          <div><strong>True Care</strong><span>Home Support</span></div>
        </a>
        <nav>
          <a href="#services">Services</a>
          <a href="#families">For Families</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
          <a className="pill" href="tel:07932506277">Contact Us</a>
        </nav>
      </header>

      <section id="home" className="hero">
        <div className="copy fade">
          <p className="eyebrow">Swansea & Port Talbot</p>
          <h1>Kind, dependable support at home</h1>
          <p className="lead">Helping older people live safely, confidently and independently at home with warm, non-medical support families can trust.</p>
          <div className="actions">
            <a className="button primary" href="tel:07932506277">Arrange a Call</a>
            <a className="button secondary" href="#services">View Services</a>
          </div>
        </div>
        <div className="photo heroPhoto">
          <div className="softPortrait">True Care</div>
        </div>
      </section>

      <section className="quick">
        <h2>We can help with:</h2>
        <div className="quickGrid">
          {services.map(({ icon: Icon, title }) => (
            <div key={title}><Icon size={28}/><span>{title}</span></div>
          ))}
        </div>
      </section>

      <section id="services" className="section">
        <div className="sectionHead">
          <p className="eyebrow">Our Services</p>
          <h2>Friendly, practical support tailored to each person</h2>
          <p>Reliable home support designed around comfort, routine and independence.</p>
        </div>
        <div className="cards">
          {services.map(({ icon: Icon, title, text }) => (
            <article className="card" key={title}>
              <div className="icon"><Icon size={30}/></div>
              <h3>{title}</h3>
              <p>{text}</p>
            </article>
          ))}
        </div>
        <div className="notice">
          <Sparkles />
          <p><strong>Important:</strong> True Care currently provides non-medical home support. We do not provide personal care, nursing care or regulated care unless properly registered to do so.</p>
        </div>
      </section>

      <section id="families" className="split">
        <div>
          <p className="eyebrow">For Families</p>
          <h2>Peace of mind for the people who love them</h2>
          <p>We know how hard it can be to balance everyday life while worrying about an older loved one. Our visits provide reassurance, practical help and companionship.</p>
          <p>Every visit is delivered with patience, kindness and respect.</p>
          <a className="button primary" href="#contact">Get in touch</a>
        </div>
        <div className="panel">
          <div><ShieldCheck/><strong>Enhanced DBS checked</strong></div>
          <div><Heart/><strong>Fully insured</strong></div>
          <div><Users/><strong>Reliable service</strong></div>
        </div>
      </section>

      <section id="about" className="section about">
        <div className="photo aboutPhoto"><div>Helping people live well at home</div></div>
        <div>
          <p className="eyebrow">About True Care</p>
          <h2>Home support that feels personal, calm and consistent</h2>
          <p>True Care Home Support was created to offer dependable, compassionate help for older people across Swansea, Port Talbot and surrounding areas.</p>
          <p>Our approach is simple: support should feel personal, comfortable, trustworthy and consistent.</p>
        </div>
      </section>

      <section id="contact" className="contact">
        <div>
          <p className="eyebrow">Contact Us</p>
          <h2>We’re here to help and happy to talk</h2>
          <p>Call today for a friendly, no-obligation chat about how True Care could support you or your loved one.</p>
          <ul>
            <li><Phone size={20}/> <a href="tel:07932506277">07932 506277</a></li>
            <li><Mail size={20}/> <a href="mailto:hello@truecarehomesupport.co.uk">hello@truecarehomesupport.co.uk</a></li>
            <li><MapPin size={20}/> Swansea, Port Talbot & surrounding areas</li>
          </ul>
        </div>
        <form>
          <h3>Send us a message</h3>
          <input placeholder="Your name" />
          <input placeholder="Phone number" />
          <input placeholder="Email address" />
          <textarea placeholder="How can we help?" rows="5"></textarea>
          <button type="button" className="button primary">Send Message</button>
        </form>
      </section>

      <footer>Helping people live well at home · © 2026 True Care Home Support</footer>
    </main>
  );
}
